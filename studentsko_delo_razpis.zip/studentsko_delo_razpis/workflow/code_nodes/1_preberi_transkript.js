// n8n Code node: »Preberi transkript«
// Način: Run Once for All Items · Jezik: JavaScript
// Prebere naloženo .txt datoteko (UTF-8 ali Windows-1250), izračuna datum sestanka in pripravi prompt za Gemini.
// Koda je identična kodi v workflow/povzetki_sestankov.json in jo lahko prilepiš neposredno v node.

const item = $input.first();
const key = Object.keys(item.binary || {})[0];
if (!key) throw new Error('Datoteka s transkriptom ni bila naložena.');
const buf = await this.helpers.getBinaryDataBuffer(0, key);
let transcript = buf.toString('utf8').replace(/^\uFEFF/, '');
if (transcript.includes('\uFFFD')) {
  try { transcript = new TextDecoder('windows-1250').decode(buf); } catch (e) {}
}
if (transcript.trim().length < 50) throw new Error('Transkript je prazen ali prekratek.');

const OUR_COMPANY = 'Novis svetovanje d.o.o.';
const m = transcript.match(/DATUM:[^\n]*?(\d{1,2})\.\s*(\d{1,2})\.\s*(\d{4})/i);
const meetingDate = m ? `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}` : 'neznan';
const SYSTEM = `Si analitik sestankov v svetovalnem podjetju __OUR_COMPANY__. Iz transkripta sestanka s stranko
pripraviš strukturirane podatke za interni poslovni sistem.

TEMELJNO PRAVILO
Uporabi izključno informacije, ki so izrečene v transkriptu. Ničesar ne sklepaj, ne dopolnjuj in
ne predpostavljaj. Če podatka ni, uporabi null ali prazen seznam. Manjkajoč podatek je boljši od
napačnega.

DOKAZI
Vsaka postavka mora imeti polje "evidence": dobeseden citat iz transkripta (največ 25 besed),
brez imena govorca in časovne oznake. Citat skopiraj točno, znak za znakom. Če postavke ne moreš
podpreti s citatom, je ne vključi.

UDELEŽENCI
Osebe iz podjetja __OUR_COMPANY__ so "internal", osebe iz podjetja stranke so "client".

ZAHTEVE STRANKE (client_requirements)
- Prva zahteva je vedno osnovna potreba stranke: problem, ki ga želi rešiti (npr. avtomatizacija
  določenega procesa, manj napak), s prioriteto "must".
- "must": stranka jo izrecno postavi kot pogoj ali glavni problem.
- "nice_to_have": stranka jo opiše kot željo, ne nujnost.
- Ideje za "kasneje" ali "zdaj ni tema" NISO zahteve – spadajo v out_of_scope_ideas.

KLJUČNA DEJSTVA (key_facts)
- Količine, proračun, časovnice, sistemi, stroški.
- Če je vrednost med sestankom popravljena, uporabi KONČNO vrednost.
- confirmed = false, če je podatek ocena, želja ali ga mora še nekdo potrditi.

NASLEDNJI KORAKI (next_steps)
- Samo naloge, ki jih je nekdo prevzel ali so bile jasno dogovorjene.
- owner: polno ime, če je oseba med udeleženci (npr. "Tilen Rozman", ne samo "Tilen"); sicer ime,
  kot je izrečeno. Če naloge nihče ni izrecno prevzel ("nekdo bi moral ..."),
  je owner null in owner_side "unknown".
- Oseba iz podjetja stranke, ki ni na sestanku, je "client" – tudi če ima enako ime kot kdo drug.
- due_date samo, če je rok izrecno dogovorjen. Relativne izraze ("do petka", "naslednji torek")
  izračunaj glede na datum sestanka __MEETING_DATE__ in nastavi due_date_type "relative_resolved".
- Želje brez zaveze ("idealno bi bilo", "ne bi še obljubljal", "čim prej") NISO roki: due_date null,
  due_date_type "none". Takšno željo zapiši v key_facts z confirmed = false.
- depends_on: ID-ji korakov, od katerih je naloga izrecno odvisna.
- Če ima korak rok, mora citat vsebovati tudi besede, ki rok določajo (npr. "Do naslednjega torka bo.").

ODPRTA VPRAŠANJA (open_questions)
Vprašanja, na katera na sestanku ni bilo odgovorjeno.

INTERNO (internal_only)
Vse, kar je izrečeno po odhodu stranke ali označeno kot interno ("med nama", "tega jim ne omenjaj"),
npr. popusti, cenovna taktika. To se nikoli ne sme pojaviti v komunikaciji s stranko.

IGNORIRAJ
Vljudnostni pogovor (vreme, pozdravi) in teme o drugih strankah.

POVZETEK (summary)
3–5 stavkov v slovenščini: stanje pri stranki, glavni problem, ključne zahteve, nepotrjene
okoliščine in naslednji korak. Brez informacij iz internal_only.

Vse vrednosti piši v slovenščini.`;
const Q = '"'.repeat(3);
const safe = transcript.replace(/{/g, '(').replace(/}/g, ')');   // LangChain: zaviti oklepaji so spremenljivke
return [{ json: {
  title: String(item.json['Naslov sestanka'] || item.binary[key].fileName || 'Sestanek'),
  transcript,
  system_prompt: SYSTEM.replaceAll('__OUR_COMPANY__', OUR_COMPANY).replaceAll('__MEETING_DATE__', meetingDate),
  user_message: `Naše podjetje: ${OUR_COMPANY}\nDatum sestanka: ${meetingDate}\n\nTRANSKRIPT:\n${Q}\n${safe}\n${Q}`,
} }];
