// n8n Code node: »3. Samodejno preverjanje«
// Način: Run Once for All Items · Jezik: JavaScript
// Deterministična validacija AI izhoda (citati, osebe, roki, številke) in HTML za stran s pregledom.
// Koda je identična kodi v workflow/povzetki_sestankov.json in jo lahko prilepiš neposredno v node.

// =====================================================================
// Validacija AI ekstrakcije – n8n Code node ("Run Once for All Items")
//
// Vhod (en item): { extraction, transcript, employees, meeting_id }
// Izhod: { meeting_id, validation: { flags, counts, blocking } }
//
// Pravilo: AI predlaga, koda preveri, človek potrdi.
// Napake (error) blokirajo potrditev, dokler jih uporabnik ne popravi.
// =====================================================================

const norm = (s) =>
  String(s ?? '')
    .toLowerCase()
    .replace(/[„“”"«»]/g, '"')
    .replace(/[‘’`´]/g, "'")
    .replace(/[–—]/g, '-')
    .replace(/…/g, '...')
    .replace(/\s+/g, ' ')
    .trim();

const tokens = (s) => norm(s).replace(/[^\p{L}\p{N}\s]/gu, ' ').split(/\s+/).filter(Boolean);

// Najboljše ujemanje citata z oknom enake dolžine v transkriptu (delež ujemajočih se besed)
function fuzzyScore(quote, transcriptTokens) {
  const q = tokens(quote);
  if (!q.length) return 0;
  let best = 0;
  for (let i = 0; i + q.length <= transcriptTokens.length; i++) {
    const win = transcriptTokens.slice(i, i + q.length);
    const bag = new Map();
    win.forEach((t) => bag.set(t, (bag.get(t) || 0) + 1));
    let hit = 0;
    for (const t of q) if (bag.get(t) > 0) { hit++; bag.set(t, bag.get(t) - 1); }
    best = Math.max(best, hit / q.length);
    if (best === 1) break;
  }
  return best;
}

// Vrstice transkripta: [hh:mm:ss] Govorec: besedilo
function parseLines(transcript) {
  return transcript.split('\n').map((l) => l.match(/^\[\d{2}:\d{2}:\d{2}\]\s*([^:]+):\s*(.*)$/))
    .filter(Boolean).map((m) => ({ speaker: m[1].trim(), text: m[2], n: norm(m[2]) }));
}
function participantNames(transcript, lines) {
  const m = transcript.match(/UDELEŽENCI:\s*([^\n]*)/i);
  const fromHeader = m ? m[1].split(',').map((p) => p.replace(/\(.*?\)/g, '').trim()).filter(Boolean) : [];
  const seen = new Map();
  [...fromHeader, ...lines.map((l) => l.speaker)].forEach((n) => { if (!seen.has(norm(n))) seen.set(norm(n), n); });
  return [...seen.values()];
}
function lineOf(evidence, lines) {
  const part = String(evidence || '').split(/\.\.\.|…/)[0].trim();
  return lines.find((l) => l.n.includes(norm(part))) || null;
}
const speakerOf = (evidence, lines) => lineOf(evidence, lines)?.speaker ?? null;
// Ime (tudi sklonjeno: Luka/Luko/Luki) je omenjeno v besedilu
const nameStem = (first) => first.slice(0, Math.max(3, first.length - 1));
const mentions = (text, first) => new RegExp(`\\b${nameStem(first)}\\p{L}*`, 'u').test(norm(text));
const TIME_WORDS = /(\d{1,2}\.\s?\d{1,2}\.|jutri|danes|pojutri|ponedelj|torek|torka|sred[aoe]|četrt|petek|petka|sobot|nedelj|januar|februar|marec|marca|april|maj[ae]?\b|junij|julij|avgust|septemb|oktob|novemb|decemb|tedn|teden|mesec|konca|konec)/;
const HEDGE_WORDS = /(idealno|mogoče|morda|mora še potrditi|ni potrjen|še nimamo|nekje sem razmišljal|ne vem)/;
const UNASSIGNED_WORDS = /\bnekdo\b/;

function parseHeaderDate(transcript) {
  const m = transcript.match(/DATUM:[^\n]*?(\d{1,2})\.\s*(\d{1,2})\.\s*(\d{4})/i);
  if (!m) return null;
  return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
}

const isIsoDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(new Date(s + 'T00:00:00Z'));
const daysBetween = (a, b) => (new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / 86400000;

function validateExtraction(extraction, transcript, employees) {
  const flags = [];
  const add = (severity, code, path, message) => flags.push({ severity, code, path, message });

  const tNorm = norm(transcript);
  const tTokens = tokens(transcript);
  const lines = parseLines(transcript);
  const names = participantNames(transcript, lines);
  const participants = new Set(names.map(norm));
  const x = extraction || {};

  // ---------- 1. Dokazi: vsak citat mora obstajati v transkriptu ----------
  const sections = ['client_requirements', 'key_facts', 'next_steps', 'open_questions', 'out_of_scope_ideas', 'internal_only'];
  for (const sec of sections) {
    (x[sec] || []).forEach((item, i) => {
      const path = `${sec}[${i}]`;
      if (item.source === 'human') return add('info', 'HUMAN_EDIT', path, 'Postavko je ročno dodal ali popravil uporabnik.');
      const ev = item.evidence;
      if (!ev || !ev.trim()) return add('error', 'EVIDENCE_MISSING', path, 'Postavka nima citata iz transkripta.');
      const parts = ev.split(/\.\.\.|…/).map((p) => p.trim()).filter((p) => p.length > 3);
      const allExact = parts.every((p) => tNorm.includes(norm(p)));
      if (allExact) return;
      const score = fuzzyScore(ev, tTokens);
      if (score >= 0.85) add('warning', 'EVIDENCE_APPROX', path, `Citat se ujema le približno (${Math.round(score * 100)} %). Preveri besedilo.`);
      else add('error', 'EVIDENCE_NOT_FOUND', path, `Citata ni v transkriptu (ujemanje ${Math.round(score * 100)} %). Možna izmišljena informacija.`);
    });
  }

  // ---------- 2. Enolični ID-ji in odvisnosti ----------
  const steps = x.next_steps || [];
  const ids = steps.map((s) => s.id);
  ids.filter((id, i) => ids.indexOf(id) !== i).forEach((id) => add('error', 'DUPLICATE_ID', 'next_steps', `Podvojen ID koraka: ${id}.`));
  steps.forEach((s, i) => (s.depends_on || []).forEach((d) => {
    if (!ids.includes(d)) add('error', 'BAD_DEPENDENCY', `next_steps[${i}]`, `Odvisnost ${d} ne obstaja.`);
  }));

  // ---------- 3. Odgovorne osebe ----------
  const emp = (employees || []).map((e) => ({ ...e, n: norm(e.name), first: norm(e.name).split(' ')[0] }));
  steps.forEach((s, i) => {
    const path = `next_steps[${i}]`;
    if (!s.owner) {
      add('warning', 'OWNER_MISSING', path, `Naloga "${s.task}" nima odgovorne osebe. Določi jo pred potrditvijo.`);
      return;
    }
    const human = s.source === 'human';
    let o = norm(s.owner);
    const first = o.split(/[\s(,]/)[0];
    // Samo ime ("Tilen") -> polno ime, če je na sestanku natanko en udeleženec s tem imenom
    if (!/[\s(,]/.test(o)) {
      const cands = names.filter((n) => norm(n).split(' ')[0] === o);
      if (cands.length === 1) {
        add('info', 'OWNER_RESOLVED', path, `"${s.owner}" dopolnjeno v "${cands[0]}" (edini udeleženec s tem imenom).`);
        s.owner = cands[0];
        o = norm(s.owner);
      }
    }
    if (!human && !tNorm.includes(first)) add('error', 'OWNER_NOT_IN_TRANSCRIPT', path, `Oseba "${s.owner}" se v transkriptu ne pojavi.`);

    const exact = emp.find((e) => e.n === o);
    const sameFirst = emp.filter((e) => e.first === first);

    // Oseba mora biti govorec citata (prevzame nalogo) ali omenjena v citatu
    const speaker = speakerOf(s.evidence, lines);
    const isSpeaker = speaker && (norm(speaker) === o || norm(speaker).split(' ')[0] === first);
    if (!human && !isSpeaker && !mentions(s.evidence, first))
      add('warning', 'OWNER_NOT_IN_EVIDENCE', path, `"${s.owner}" ni govorec citata in v njem ni omenjen. Dodelitev je lahko ugibanje.`);
    if (!human && UNASSIGNED_WORDS.test(norm(s.evidence)))
      add('warning', 'OWNER_GUESSED', path, `Citat pravi "nekdo", AI pa je nalogo dodelil osebi "${s.owner}".`);
    if (s.owner_side === 'internal' && exact && !participants.has(exact.n))
      add('warning', 'OWNER_NOT_PARTICIPANT', path, `${exact.name} ni bil na sestanku. Preveri, ali je naloga res njegova (npr. oseba z enakim imenom pri stranki).`);

    if (s.owner_side === 'internal') {
      if (exact) s._employee_id = exact.id;
      else if (sameFirst.length === 1) add('warning', 'OWNER_PARTIAL_MATCH', path, `"${s.owner}" se delno ujema z zaposlenim ${sameFirst[0].name}. Potrdi osebo.`);
      else add('error', 'OWNER_NOT_EMPLOYEE', path, `"${s.owner}" je označen kot interni, a ni med zaposlenimi.`);
    } else if (s.owner_side === 'client') {
      if (exact) add('error', 'CLIENT_OWNER_IS_EMPLOYEE', path, `"${s.owner}" je označen kot stranka, a je interni zaposleni.`);
      else if (sameFirst.length) add('warning', 'NAME_COLLISION', path, `"${s.owner}" (stranka) ima enako ime kot interni zaposleni ${sameFirst.map((e) => e.name).join(', ')}. Preveri, da naloga ni dodeljena napačni osebi.`);
    } else {
      add('warning', 'OWNER_SIDE_UNKNOWN', path, `Ni jasno, ali je "${s.owner}" interni zaposleni ali stranka.`);
    }
  });

  // ---------- 4. Datumi ----------
  const headerDate = parseHeaderDate(transcript);
  const meetingDate = x.meeting?.date;
  if (headerDate && meetingDate && headerDate !== meetingDate)
    add('error', 'MEETING_DATE_MISMATCH', 'meeting.date', `Datum sestanka (${meetingDate}) se ne ujema z glavo transkripta (${headerDate}).`);
  const baseDate = headerDate || meetingDate;

  steps.forEach((s, i) => {
    const path = `next_steps[${i}]`;
    if (s.due_date == null) {
      if (s.due_date_type !== 'none') add('error', 'DATE_INCONSISTENT', path, 'Tip roka je nastavljen, datum pa manjka.');
      return;
    }
    if (!isIsoDate(s.due_date)) return add('error', 'DATE_INVALID', path, `Neveljaven datum: ${s.due_date}.`);
    if (s.due_date_type === 'none') add('error', 'DATE_INCONSISTENT', path, 'Datum je nastavljen, čeprav rok ni bil dogovorjen.');
    const line = lineOf(s.evidence, lines);
    if (s.source !== 'human' && !TIME_WORDS.test(norm(s.evidence)) && !(line && TIME_WORDS.test(line.n)))
      add('error', 'DATE_NOT_IN_EVIDENCE', path, `Rok ${s.due_date} nima opore v izjavi govorca (ni časovnega izraza). Možno izmišljen rok.`);
    if (baseDate) {
      const d = daysBetween(baseDate, s.due_date);
      if (d < 0) add('error', 'DATE_IN_PAST', path, `Rok ${s.due_date} je pred datumom sestanka.`);
      else if (d > 365) add('warning', 'DATE_FAR', path, `Rok ${s.due_date} je več kot leto dni po sestanku.`);
    }
    if (s.due_date_type === 'relative_resolved')
      add('info', 'DATE_RELATIVE', path, `Rok ${s.due_date} je izračunan iz relativnega izraza. Preveri.`);
  });

  // ---------- 5. Številke v povzetku morajo imeti vir v ključnih dejstvih ----------
  const factText = norm((x.key_facts || []).map((f) => f.value).join(' '));
  const nums = (norm(x.summary).match(/\d[\d.,]*/g) || []).map((n) => n.replace(/[.,]$/, ''));
  nums.forEach((n) => {
    if (!factText.includes(n)) add('warning', 'SUMMARY_NUMBER_UNSOURCED', 'summary', `Številka "${n}" v povzetku nima vira v ključnih dejstvih.`);
  });

  // ---------- 6. Informativne oznake ----------
  (x.key_facts || []).forEach((f, i) => {
    if (f.confirmed === true && HEDGE_WORDS.test(norm(f.evidence)))
      add('warning', 'HEDGED_BUT_CONFIRMED', `key_facts[${i}]`, `"${f.topic}" je označen kot potrjen, citat pa izraža negotovost.`);
    if (f.confirmed === false) add('info', 'UNCONFIRMED', `key_facts[${i}]`, `Nepotrjeno: ${f.topic} – ${f.value}.`);
  });
  if ((x.internal_only || []).length)
    add('info', 'INTERNAL_EXCLUDED', 'internal_only', `${x.internal_only.length} interna opomba bo izključena iz sporočila stranki.`);

  const counts = { error: 0, warning: 0, info: 0 };
  flags.forEach((f) => counts[f.severity]++);
  return { flags, counts, blocking: counts.error > 0 };
}

const EMPLOYEES = [{"id": "EMP-001", "name": "Maja Kranjc", "role": "Projektna vodja"}, {"id": "EMP-002", "name": "Tilen Rozman", "role": "Tehnični svetovalec"}, {"id": "EMP-003", "name": "Luka Novak", "role": "Svetovalec"}, {"id": "EMP-004", "name": "Nina Zupan", "role": "Vodja prodaje"}]; // v produkciji: iz kadrovskega sistema ali CRM prek API

const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const src = $('Preberi transkript').first().json;
const x = $input.first().json.output;
const v = validateExtraction(x, src.transcript, EMPLOYEES);

const PRI = { must: 'nujno', should: 'zaželeno', nice_to_have: 'želja', unknown: '?' };
const ICON = { error: '❌', warning: '⚠️', info: 'ℹ️' };
const flagsFor = (path) => v.flags.filter((f) => f.path === path && f.severity !== 'info')
  .map((f) => `<br>${ICON[f.severity]} <i>${esc(f.message)}</i>`).join('');

let h = `<p><b>${esc(x.meeting?.client_company)}</b>, ${esc(x.meeting?.date)}</p>`;
h += `<h3>Povzetek</h3><p>${esc(x.summary)}</p>`;
h += '<h3>Zahteve stranke</h3><ul>' + (x.client_requirements || []).map((r, i) =>
  `<li>[${PRI[r.priority] || r.priority}] ${esc(r.description)}${flagsFor(`client_requirements[${i}]`)}</li>`).join('') + '</ul>';
h += '<h3>Naslednji koraki</h3><ul>' + (x.next_steps || []).map((s, i) =>
  `<li><b>${esc(s.task)}</b><br>Odgovoren: ${s.owner ? esc(s.owner) + (s.owner_side === 'client' ? ' (stranka)' : '') : '<b>– ni določen –</b>'}` +
  `${s.due_date ? ' · rok: ' + esc(s.due_date) : ''}<br><small>»${esc(s.evidence)}«</small>${flagsFor(`next_steps[${i}]`)}</li>`).join('') + '</ul>';
h += '<h3>Ključna dejstva</h3><ul>' + (x.key_facts || []).map((f, i) =>
  `<li>${esc(f.topic)}: ${esc(f.value)}${f.confirmed ? '' : ' <i>(nepotrjeno)</i>'}${flagsFor(`key_facts[${i}]`)}</li>`).join('') + '</ul>';
if ((x.open_questions || []).length) h += '<h3>Odprta vprašanja</h3><ul>' + x.open_questions.map((q) => `<li>${esc(q.question)}</li>`).join('') + '</ul>';
if ((x.internal_only || []).length) h += '<h3>🔒 Interno – ne gre stranki</h3><ul>' + x.internal_only.map((n) => `<li>${esc(n.note)}</li>`).join('') + '</ul>';
const other = v.flags.filter((f) => f.severity !== 'info' && !/^(client_requirements|next_steps|key_facts)\[/.test(f.path));
h += `<h3>Samodejno preverjanje</h3><p>${v.counts.error} napak · ${v.counts.warning} opozoril · vsak podatek ima citat iz transkripta</p>`;
if (other.length) h += '<ul>' + other.map((f) => `<li>${ICON[f.severity]} ${esc(f.message)}</li>`).join('') + '</ul>';
if (v.blocking) h += '<p>❌ <b>Podatki vsebujejo napake, zato jih ni mogoče zapisati.</b> Izberi »Zavrni«.</p>';

return [{ json: { extraction: x, validation: v, review_html: h } }];
