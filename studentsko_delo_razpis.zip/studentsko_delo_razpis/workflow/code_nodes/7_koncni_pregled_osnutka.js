// n8n Code node: »Končni pregled osnutka«
// Način: Run Once for All Items · Jezik: JavaScript
// Zadnja varovalka: preveri, da osnutek follow-upa ne omenja internih tem, in pripravi stran z rezultatom.
// Koda je identična kodi v workflow/povzetki_sestankov.json in jo lahko prilepiš neposredno v node.

const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const a = $('5. Uporabi odločitev').first().json;
const draft = String($input.first().json.text || '').trim();
// Zadnja varovalka: osnutek za stranko ne sme omenjati internih tem
const leaks = ['popust', 'odstot', '%', 'proračun', 'med nama', 'interno'].filter((w) => draft.toLowerCase().includes(w));
let h = '<h3>✅ Zapisano v poslovni sistem</h3><ul>' + a.tasks.map((t) =>
  `<li>${esc(t.naloga)} – ${esc(t.odgovoren || 'ni določen')}${t.rok ? ', rok ' + esc(t.rok) : ''}</li>`).join('') + '</ul>';
h += '<h3>Osnutek follow-up sporočila</h3>';
if (!draft) h += '<p>⚠️ AI osnutka ni mogel pripraviti (storitev ni na voljo). Podatki so kljub temu zapisani.</p>';
else {
  if (leaks.length) h += `<p>⚠️ <b>Preveri pred pošiljanjem:</b> osnutek omenja »${esc(leaks.join('«, »'))}«.</p>`;
  h += '<p>' + esc(draft).replace(/\n/g, '<br>') + '</p>';
}
h += '<p><small>Osnutek se ne pošlje samodejno – pošlje ga svetovalec po pregledu.</small></p>';
return [{ json: { result_html: h } }];
