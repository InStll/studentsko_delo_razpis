// Lokalni test validacije: node test_validate.js
// GOLD = pravilen izhod, BAD = tipične napake AI, HEDGED = napačno potrjen podatek
const fs = require('fs');
const path = require('path');
const { validateExtraction } = require(path.join(__dirname, 'validate.js'));
const base = path.join(__dirname, '..', 'testni_podatki') + path.sep;
const transcript = fs.readFileSync(base + 'transkript_sestanek.txt', 'utf8');
const employees = JSON.parse(fs.readFileSync(base + 'zaposleni.json', 'utf8')).employees;
const gold = JSON.parse(fs.readFileSync(base + 'pricakovan_izhod.json', 'utf8'));

const show = (name, r) => {
  console.log(`\n=== ${name}: ${JSON.stringify(r.counts)} blocking=${r.blocking}`);
  r.flags.forEach(f => console.log(`  [${f.severity}] ${f.code} ${f.path}: ${f.message}`));
};
show('GOLD', validateExtraction(JSON.parse(JSON.stringify(gold)), transcript, employees));

// "Bad" output simulating typical AI mistakes (each maps to a trap)
const bad = JSON.parse(JSON.stringify(gold));
bad.summary = bad.summary.replace('približno 250', 'približno 150');                     // stale number
bad.next_steps[3].owner = 'Luka Novak'; bad.next_steps[3].owner_side = 'internal';        // Luka confusion
bad.next_steps[1].due_date = '2026-10-31'; bad.next_steps[1].due_date_type = 'explicit';  // invented deadline (evidence still ok)
bad.next_steps[4].owner = 'Petra Vidmar'; bad.next_steps[4].owner_side = 'client';        // guessed owner (evidence = "nekdo bi moral")
bad.key_facts[4].confirmed = true;
bad.key_facts[4].evidence = 'Andrej je potrdil proračun petnajst tisoč evrov.';          // hallucinated quote
bad.meeting.date = '2026-09-16';                                                           // wrong date
show('BAD', validateExtraction(bad, transcript, employees));

// Hedged-but-confirmed check (evidence still genuine)
const hedged = JSON.parse(JSON.stringify(gold));
hedged.key_facts[4].confirmed = true;
show('HEDGED', validateExtraction(hedged, transcript, employees));

// Human edit: reviewer assigns the orphan task to Maja and sets a deadline by hand
const human = JSON.parse(JSON.stringify(gold));
Object.assign(human.next_steps[4], { owner: 'Maja Kranjc', owner_side: 'internal', due_date: '2026-09-25', due_date_type: 'explicit', source: 'human' });
show('HUMAN', validateExtraction(human, transcript, employees));

// Real Gemini run #4 (first names only, deadline quote cut short)
const run4 = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'gemini_run_4.json'), 'utf8'));
const r4 = validateExtraction(run4, transcript, employees);
show('GEMINI_RUN_4', r4);
console.log('  owners after resolution:', run4.next_steps.map((s) => s.owner).join(' | '));
